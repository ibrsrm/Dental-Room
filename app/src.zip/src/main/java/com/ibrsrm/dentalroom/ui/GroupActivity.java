package com.ibrsrm.dentalroom.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.ibrsrm.dentalroom.R;
import com.ibrsrm.dentalroom.adapters.GlideApp;
import com.ibrsrm.dentalroom.adapters.MessageRVAdapter;
import com.ibrsrm.dentalroom.model.Config.ConfigManager;
import com.ibrsrm.dentalroom.model.Repository.Common.Group;
import com.ibrsrm.dentalroom.model.Repository.Common.Message;
import com.ibrsrm.dentalroom.viewmodels.MessagesViewModel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class GroupActivity extends AppCompatActivity {

    private Toolbar mToolBar;
    private EditText mText;
    private Button mSend;
    private Spinner mRating;
    private AlertDialog mDialog;
    private RecyclerView mMessagesRecyclerView;
    private MessagesViewModel mMessagesViewModel;
    private MessageRVAdapter mAdapter;
    private ImageView mXrayimageView;
    private TextView mComment;
    private TextView mMembers;

    private String mUID;
    private Group mGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        /* Get Group ID */
        Intent intent = getIntent();
        mUID = intent.getStringExtra("GROUP_UID");
        mGroup = ConfigManager.getInstance().getRepositoryManager().getGroup(mUID);
        mGroup.setNewMessageStatus(false);

        mToolBar = findViewById(R.id.toolbarGroup);
        setSupportActionBar(mToolBar);
        getSupportActionBar().setTitle(mGroup.getName());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        /* Initialize views */
        mText = findViewById(R.id.editTextInput);
        mSend = findViewById(R.id.sendButton);
        mMessagesRecyclerView = findViewById(R.id.recyclerViewGroupMessages);
        mRating = findViewById(R.id.spinnerInputComment);
        mXrayimageView = findViewById(R.id.imageViewXRay);
        mComment = findViewById(R.id.textComment);
        mMembers = findViewById(R.id.groupMembers);

        String[] values = getResources().getStringArray(R.array.SpinnerValues);
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values);
        mRating.setAdapter(adapter);

        /* Initialize Message Recycler View Layout*/
        LinearLayoutManager recyclerLayoutManager = new LinearLayoutManager(this);
        mMessagesRecyclerView.setLayoutManager(recyclerLayoutManager);
        DividerItemDecoration divider = new DividerItemDecoration(mMessagesRecyclerView.getContext(), DividerItemDecoration.VERTICAL);
        divider.setDrawable(ContextCompat.getDrawable(getBaseContext(), R.drawable.divider));
        mMessagesRecyclerView.addItemDecoration(divider);

        /* Initialize view model */
        mMessagesViewModel = ViewModelProviders.of(this).get(MessagesViewModel.class);
        mMessagesViewModel.initialize(mUID);

        /* Initialize Adapter */
        mAdapter = new MessageRVAdapter(getApplicationContext(), mMessagesViewModel.getMessages(mUID));
        mMessagesRecyclerView.setAdapter(mAdapter);

        if (mGroup.getUrl() != null) {
            /* TODO: find a better way */
            StorageReference ref = FirebaseStorage.getInstance().getReference().child(mGroup.getUrl());
            GlideApp.with(getApplicationContext())
                    .load(ref)
                    .into(mXrayimageView);
        }
        if (mGroup.getComment() != null) {
            mComment.setText(mGroup.getComment());
        }
        if (mGroup.getMembers() != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(mMembers.getText().toString());
            sb.append("\n");
            Iterator<Map.Entry<String, String>> iterator = mGroup.getMembers().entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = iterator.next();
                sb.append(entry.getValue());
                sb.append("\n");
            }
            mMembers.setText(sb.toString());
        }

        setActions();
    }

    private void setActions() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        });

        mSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rating = mRating.getSelectedItem().toString();
                String input = mText.getText().toString();
                if (rating.equals("Rating") || input.isEmpty()) {
                    showErrorDialog();
                } else {
                    mMessagesViewModel.sendMessage(mUID, input, rating);
                }
            }
        });

        mMessagesViewModel.getMessagesLiveData().observe(this, new Observer<ArrayList<Message>>() {
            @Override
            public void onChanged(ArrayList<Message> messages) {
                mAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onPause() {
        hideErrorDialog();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        hideErrorDialog();
        super.onDestroy();
    }

    private void showErrorDialog() {
        if (mDialog == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Send Message Failed");
            builder.setMessage("Please add an input and select rating");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            mDialog = builder.create();
        }
        mDialog.show();
    }

    private void hideErrorDialog() {
        if (mDialog != null) {
            mDialog.dismiss();
        }
    }

}
