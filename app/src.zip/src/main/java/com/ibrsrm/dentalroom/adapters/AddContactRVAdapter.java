package com.ibrsrm.dentalroom.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ibrsrm.dentalroom.R;
import com.ibrsrm.dentalroom.model.Repository.Common.Contact;

import java.util.HashSet;
import java.util.List;

public class AddContactRVAdapter extends RecyclerView.Adapter<AddContactRVAdapter.ViewHolder> {

    private Context mContext;
    private List<Contact> mContacts;
    private HashSet<Contact> mSet;

    public AddContactRVAdapter(Context context, List<Contact> contacts) {
        this.mContacts = contacts;
        this.mContext = context;
        mSet = new HashSet<>();
    }

    public HashSet<Contact> getContactSet() {
        return mSet;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_contacts, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Log.e("onBindViewHolder", "pos:" + position);
        Contact contact = mContacts.get(position);
        holder.mNick.setText(contact.getNick());
        holder.mEmail.setText(contact.getMail());

        holder.mAddCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mSet.add(mContacts.get(holder.getAdapterPosition()));
                } else {
                    mSet.remove(mContacts.get(holder.getAdapterPosition()));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mContacts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView mNick;
        public TextView mEmail;
        public CheckBox mAddCheckBox;

        public ViewHolder(View itemView) {
            super(itemView);
            mNick = itemView.findViewById(R.id.textViewNickName);
            mEmail = itemView.findViewById(R.id.textViewNickMail);
            mAddCheckBox = itemView.findViewById(R.id.userAddCheckBox);
        }

    }

}
