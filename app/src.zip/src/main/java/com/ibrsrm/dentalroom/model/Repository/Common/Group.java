package com.ibrsrm.dentalroom.model.Repository.Common;

import android.util.Log;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@IgnoreExtraProperties
public class Group {

    private final static String TAG = "Group:";

    private String uid;
    private String name;
    private String comment;
    private String url;

    private Map<String, String> members;
    private ArrayList<Message> messages;

    private boolean mNewMessage;

    public Group() {
        if (messages == null) {
            messages = new ArrayList<>();
        }
    }

    public Group(String _uid, String _name, String _comment, String _url) {
        this.uid = _uid;
        this.name = _name;
        this.comment = _comment;
        this.url = _url;
        members = new HashMap<>();
        messages = new ArrayList<>();
    }

    public String getUid () {
        return this.uid;
    }

    public String getName () {
        return this.name;
    }

    public String getComment () {
        return this.comment;
    }

    public String getUrl () {
        return this.url;
    }

    public Map<String, String> getMembers() {
        return this.members;
    }

    @Exclude
    public void addMember (String uid, String mail) {
        members.put(uid, mail);
    }

    @Exclude
    public boolean getNewMessageStatus () {
        return mNewMessage;
    }

    @Exclude
    public boolean setNewMessageStatus (boolean newMessage) {
        return mNewMessage = newMessage;
    }

    @Exclude
    public ArrayList<Message> getMessages() {
        return messages;
    }

    @Exclude
    public void addMessage(Message message) {
        messages.add(message);
        mNewMessage = true;
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("uid", uid);
        result.put("name", name);
        result.put("comment", comment);
        result.put("url", url);
        result.put("members", members);
        return result;
    }

    public void print() {
        Log.e("TAG:", "===");
        Log.e("\tUID:", uid);
        Log.e("\tNAME:", name);
        Log.e("\tURL:", url);

        Iterator <Map.Entry<String, String>> iterator = members.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            Log.e("\tMEMBER:", entry.getKey() + ":" + entry.getValue());
        }
    }

}
